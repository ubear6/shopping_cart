#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    bank.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:56
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:56      youbing      1.0         None
"""
import datetime
from db import db_handler

time = datetime.datetime.now()


def balance_interface(username):
    """查看余额接口"""
    user_dic = db_handler.read_json(username)
    return user_dic['balance']


def transfer_interface(from_username, to_username, money):
    """转账接口"""
    to_user_dic = db_handler.read_json(to_username)
    if to_user_dic:
        from_user_dic =  db_handler.read_json(from_username)
        if money > from_user_dic['balance']:
            return False, "余额不足！"
        from_user_dic['balance'] -= money
        to_user_dic['balance'] += money

        from_user_flow = f"{time}: {from_username}向{to_username}转账{money}元，操作成功！"
        from_user_dic['bank_flow'].append(from_user_flow)

        to_user_flow = f"{time}: {to_username}收到{from_username}转账{money}元，操作成功！"
        to_user_dic['bank_flow'].append(to_user_flow)

        db_handler.save_json(from_username, from_user_dic)
        db_handler.save_json(to_username, to_user_dic)
        return True, f"{from_username}向{to_username}转账{money}元，操作成功！"
    return False, f"用户{to_username}不存在！"


def repay_interface(username, money):
    """还款接口"""
    user_dic = db_handler.read_json(username)
    user_dic['balance'] += money

    user_flow = f"{time}: {username}还款{money}元，操作成功！"
    user_dic['bank_flow'].append(user_flow)

    db_handler.save_json(username, user_dic)
    return True, f"{username}还款{money}元，操作成功！"


def withdraw_interface(username, money):
    """取款接口"""
    user_dic = db_handler.read_json(username)
    if money > user_dic['balance']:
        return False, "余额不足！"
    user_dic['balance'] -= money

    user_flow = f"{time}: {username}取款{money}元，操作成功！"
    user_dic['bank_flow'].append(user_flow)

    db_handler.save_json(username, user_dic)
    return True, f"{username}取款{money}元，操作成功！"


def flow_interface(username):
    """查看流水接口"""
    user_dic = db_handler.read_json(username)
    return user_dic['bank_flow']


def bank_pay_interface(username, total_price):
    """银行结算接口"""
    user_dic = db_handler.read_json(username)
    if total_price > user_dic['balance']:
        return False, "余额不足！"
    user_dic['balance'] -= total_price
    user_flow = f"{time}: {username}支付{total_price}元，操作成功！"
    user_dic['bank_flow'].append(user_flow)
    db_handler.save_json(username, user_dic)
    return True, f"{username}支付{total_price}元，操作成功！"