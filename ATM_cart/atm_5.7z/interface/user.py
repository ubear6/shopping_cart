#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    user.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:29
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:29      youbing      1.0         None
"""
from db import db_handler
from core import src


def signup_interface(username, pwd):
    """注册接口"""
    user_dic = db_handler.read_json(username)
    if user_dic:
        return False, "用户已存在！"
    user_dic = {'username': username, 'pwd': pwd, 'locked': 0, 'balance': 10000, 'bank_flow': [], 'cart': []}
    db_handler.save_json(username, user_dic)
    return True, f"{username} 注册成功！"


def login_interface(username, pwd):
    """登录接口"""
    user_dic = db_handler.read_json(username)
    if user_dic:
        if user_dic['pwd'] == pwd:
            src.user_auth['user'] = username
            return True, f"{username} 登录成功！"
        return False, "登录失败，请检查用户名或密码！"
    return False, "用户不存在！"


def logout_interface():
    """注销接口"""
    src.user_auth['user'] = None
    return True, "注销成功！"