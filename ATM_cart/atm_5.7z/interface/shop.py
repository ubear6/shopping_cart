#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    shop.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 18:07
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 18:07      youbing      1.0         None
"""
from db import db_handler
from interface import bank


def goods_list_interface():
    """商品列表接口"""
    goods_list = db_handler.read_goods()
    return goods_list


def shopping_interface(username, choice, count):
    """购物接口"""
    goods_list = db_handler.read_goods()
    for goods_dic in goods_list:
        if goods_dic['商品编号'] == choice:
            if count > goods_dic['商品数量']:
                return False, "数量不足！"
            user_dic = db_handler.read_json(username)
            for cart_dic in user_dic['cart']:
                if cart_dic['商品编号'] == choice:
                    goods_dic['商品数量'] -= count
                    cart_dic['商品数量'] += count
                    break

            else:
                cart_dic = goods_dic.copy()
                cart_dic['商品数量'] = count
                user_dic['cart'].append(cart_dic)
            db_handler.save_json(username, user_dic)
            db_handler.save_goods(goods_list)
            return True, f"{goods_dic['商品名称']}x{count}加入购物车，操作成功！"

    return False, "没有这个商品！"


def cart_list_interface(username):
    """购物车列表接口"""
    total_price = 0
    user_dic = db_handler.read_json(username)
    for cart_dic in user_dic['cart']:
        total_price += cart_dic['商品数量'] * cart_dic['价格']
    return user_dic['cart'], total_price


def cart_interface(username, choice, count):
    """购物车接口"""
    user_dic = db_handler.read_json(username)
    for cart_dic in user_dic['cart']:
        if cart_dic['商品编号'] == choice:
            if count > cart_dic['商品数量']:
                return False, "数量不足！"
            goods_list = db_handler.read_goods()
            for goods_dic in goods_list:
                if goods_dic['商品编号'] == choice:
                    goods_dic['商品数量'] += count
                    cart_dic['商品数量'] -= count
                    break
            if cart_dic['商品数量'] == 0:
                user_dic['cart'].remove(cart_dic)
            db_handler.save_json(username, user_dic)
            db_handler.save_goods(goods_list)

            return True, f"{cart_dic['商品名称']}x{count}移出购物车，操作成功！"

    return False, "没有这个商品！"


def shop_pay_interface(username, total_price):
    """商城结算接口"""
    flag, msg = bank.bank_pay_interface(username, total_price)
    return flag, msg