#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    run.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:06
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:06      youbing      1.0         None
"""
from core import src


if __name__ == '__main__':
    src.run()