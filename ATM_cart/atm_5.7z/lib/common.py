#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    common.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:57
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:57      youbing      1.0         None
"""
from core import src


# 登录装饰器
def login_auth(func):
    def wrapper(*args, **kwargs):
        if src.user_auth.get('user'):
            res = func(*args, **kwargs)
            return res
        src.login()
    return wrapper
