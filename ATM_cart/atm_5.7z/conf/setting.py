#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    setting.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:06
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:06      youbing      1.0         None
"""
import os

atm_path = os.path.dirname(os.path.dirname(__file__))
db_path = os.path.join(atm_path, 'db')
user_path = os.path.join(db_path, 'user_info')
log_path = os.path.join(atm_path, 'log,log')


# ATM欢迎页
menu_msg = """
————————————————————————————————————
          欢迎来到最右ATM

              1. 登录
              2. 注册
              3. 查看余额
              4. 转账
              5. 还款
              6. 取现
              7. 查看流水
              8. 购物
              9. 购物车
              0. 注销
              q. 退出
————————————————————————————————————  
"""