#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    src.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:10
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:10      youbing      1.0         None
"""
from conf import setting
from interface import user, bank, shop
from lib import common

user_auth = {'user': None}


def signup():
    """注册功能"""
    print("欢迎注册")
    while True:
        username = input("请输入用户名，q退出：").strip()
        if username.upper() == 'Q':
            break
        elif not username:
            print("非法输入")
            continue
        pwd = input("请输入密码：").strip()
        re_pwd = input("请q确认密码：").strip()
        if pwd == re_pwd:
            flag, msg = user.signup_interface(username, pwd)
            print(msg)
            if flag:
                break
        else:
            print("密码不一致！")


def login():
    """登录功能"""
    print("欢迎登陆")
    while True:
        username = input("请输入用户名，q退出：").strip()
        if username.upper() == 'Q':
            break
        elif not username:
            print("非法输入")
            continue

        pwd = input("请输入密码：").strip()
        flag, msg = user.login_interface(username, pwd)
        print(msg)
        if flag:
            break


@common.login_auth
def balance():
    """查看流水功能"""
    print("欢迎查看流水")
    balance_count = bank.balance_interface(user_auth.get('user'))
    print(f"你的剩余额度为{balance_count}元")


@common.login_auth
def transfer():
    """转账功能"""
    print("欢迎转账")
    while True:
        to_username = input("请输入转入账户，q退出：").strip()
        if to_username.upper() == 'Q':
            break
        elif to_username == user_auth.get('user'):
            print("不能给自己转账！")
            continue
        money = input("请输入转账金额，q退出：").strip()
        if not money.isdigit():
            print("转账金额必须为数字！")
            continue
        money = int(money)

        flag, msg = bank.transfer_interface(user_auth.get('user'), to_username, money)
        print(msg)


@common.login_auth
def repay():
    """还款功能"""
    print("欢迎还款")
    while True:
        balance_count = bank.balance_interface(user_auth.get('user'))
        print(f"你的剩余额度为{balance_count}元")
        money = input("请输入还款金额，q退出：").strip()
        if money.upper() == 'Q':
            break
        elif not money.isdigit():
            print("还款金额必须为数字！")
            continue
        money = int(money)

        flsg, msg = bank.repay_interface(user_auth.get('user'), money)
        print(msg)


@common.login_auth
def withdraw():
    """提现功能"""
    print("欢迎取款")
    while True:
        balance_count = bank.balance_interface(user_auth.get('user'))
        print(f"你的剩余额度为{balance_count}元")
        money = input("请输入取款金额，q退出：").strip()
        if money.upper() == 'Q':
            break
        elif not money.isdigit():
            print("取款金额必须为数字！")
            continue
        money = int(money)

        flsg, msg = bank.withdraw_interface(user_auth.get('user'), money)
        print(msg)


@common.login_auth
def flow():
    """查看流水"""
    print("欢迎查看流水")
    flow_list = bank.flow_interface(user_auth.get('user'))
    if flow_list:
        for flw in flow_list:
            print(flw)
    else:
        print("没有流水记录！")


@common.login_auth
def shopping():
    """商城"""
    print("欢迎来到商城")
    while True:
        goods_list = shop.goods_list_interface()
        for key in goods_list[0]:
            print(f'{key:^12}', end='')
        print('\n')
        for goods_dic in goods_list:
            for value in goods_dic.values():
                print(f'{value:^14}', end='')
            print('\n')

        choice = input("输入编号加入购物车，q退出：").strip()
        if choice.upper() == 'Q':
            break

        count = input("输入购买数量：").strip()
        if not count.isdigit():
            print("数量必须为数字！")
            continue
        count = int(count)

        flag, msg = shop.shopping_interface(user_auth.get('user'), choice, count)
        print(msg)


@common.login_auth
def cart():
    """购物车"""
    print("欢迎来到购物车")
    while True:
        cart_list, total_price = shop.cart_list_interface(user_auth.get('user'))
        if cart_list:
            for key in cart_list[0]:
                print(f'{key:^12}', end='')
            print('\n')
            for goods_dic in cart_list:
                for value in goods_dic.values():
                    print(f'{value:^14}', end='')
                print('\n')

            print(f"商品总价{total_price}元")

            choice = input("输入编号移出购物车，p支付，q退出：").strip()
            if choice.upper() == 'Q':
                break
            elif choice.upper() == 'P':
                flag, msg = shop.shop_pay_interface(user_auth.get('user'), total_price)
                print(msg)
                if flag:
                    break

            count = input("输入购买数量：").strip()
            if not count.isdigit():
                print("数量必须为数字！")
                continue
            count = int(count)

            flag, msg = shop.cart_interface(user_auth.get('user'), choice, count)
            print(msg)
        else:
            print("购物车为空！")
            break


def logout():
    """注销登录"""
    print("注销")
    if user_auth.get('user'):
        choice = input("确定注销(Y), 任意键取消：")
        if choice.upper() == 'Y':
            flag, msg = user.logout_interface()
            print(msg)
    else:
        print("你还未登录！")


menu_dic = {
            '1': login,
            '2': signup,
            '3': balance,
            '4': transfer,
            '5': repay,
            '6': withdraw,
            '7': flow,
            '8': shopping,
            '9': cart,
            '0': logout,
            }


def run():
    """主函数"""
    while True:
        print(setting.menu_msg)
        choice = input("请选择功能：").strip()
        if choice.upper() == 'Q':
            print("谢谢惠顾，欢迎下次光临！")
            break
        elif choice not in menu_dic:
            print("没有这个功能！")
            continue
        menu_dic[choice]()