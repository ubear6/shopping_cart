#!/usr/bin/env python
# -*- encoding: utf-8 -*-
"""
@Project: atm_5
@File:    db_handler.py
@Author:  youbing
@Mail:    420255586@qq.com
@Time:    2019/8/22 16:30
@IDE:     PyCharm

@Modify Time         @Author    @Version    @Desciption
---------------      -------    --------    -----------
2019/8/22 16:30      youbing      1.0         None
"""
import os
import json
from conf import setting


def read_json(username):
    """读取文件"""
    path = os.path.join(setting.user_path, f'{username}.json')
    if os.path.exists(path):
        with open(path, 'r', encoding='utf8') as fr:
            data = json.load(fr)
        return data


def save_json(username, data):
    """写入文件"""
    path = os.path.join(setting.user_path, f'{username}.json')
    with open(path, 'w', encoding='utf8') as fw:
        json.dump(data, fw)


def read_goods():
    """读取商品文件"""
    path = os.path.join(setting.db_path, 'goods_info.json')
    with open(path, 'r', encoding='utf8') as fr:
        data = json.load(fr)
    return data


def save_goods(data):
    """写入商品文件"""
    path = os.path.join(setting.db_path, 'goods_info.json')
    with open(path, 'w', encoding='utf8') as fw:
        json.dump(data, fw)